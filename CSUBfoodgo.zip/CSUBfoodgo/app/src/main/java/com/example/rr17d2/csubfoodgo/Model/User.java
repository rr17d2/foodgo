package com.example.rr17d2.csubfoodgo.Model;

public class User {
    private String Email;
    private String Password;
    private String Name;
    public String Phone;

    public User() {

    }

    public User(String email, String name, String password) {
        //Phone = phone;
        Email = email;
        Password = password;
        Name = name;

    }

    /*public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }
    */

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

}
